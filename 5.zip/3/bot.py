import json
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

KEYS_FILE = "keys.json"
ADMIN_IDS = [7131749034]

def is_admin(user_id):
    return user_id in ADMIN_IDS

def load_keys():
    try:
        with open(KEYS_FILE, "r") as f:
            return json.load(f)
    except:
        return {}

def save_keys(data):
    with open(KEYS_FILE, "w") as f:
        json.dump(data, f, indent=2)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Bot quản lý API đã sẵn sàng.")

async def add_key(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return await update.message.reply_text("Permission denied.")
    try:
        key = context.args[0]
        user = context.args[1]
        maxCons = int(context.args[2])
        time_limit = int(context.args[3])
        cooldown = int(context.args[4])
        vip = context.args[5].lower() in ["1", "true", "yes", "on"]
        admin = context.args[6].lower() in ["1", "true", "yes", "on"]
        expiry = context.args[7]

        keys = load_keys()
        if key in keys:
            return await update.message.reply_text("Key đã tồn tại.")
        keys[key] = {
            "user": user,
            "maxCons": maxCons,
            "time": time_limit,
            "cooldown": cooldown,
            "vip": vip,
            "admin": admin,
            "expiry": expiry,
            "banned": False
        }
        save_keys(keys)
        await update.message.reply_text(f"Đã thêm key `{key}`.")
    except:
        await update.message.reply_text("Sai cú pháp.\n/addkey <key> <user> <maxCons> <time> <cooldown> <vip> <admin> <expiry>")

async def del_key(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return await update.message.reply_text("Permission denied.")
    try:
        key = context.args[0]
        keys = load_keys()
        if key not in keys:
            return await update.message.reply_text("Key không tồn tại.")
        del keys[key]
        save_keys(keys)
        await update.message.reply_text(f"Đã xoá key `{key}`.")
    except:
        await update.message.reply_text("Sai cú pháp.\n/delkey <key>")

async def edit_key(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return await update.message.reply_text("Permission denied.")
    try:
        key = context.args[0]
        field = context.args[1]
        value = context.args[2]

        keys = load_keys()
        if key not in keys:
            return await update.message.reply_text("Key không tồn tại.")
        if field not in ["maxCons", "time", "cooldown", "vip", "admin", "expiry"]:
            return await update.message.reply_text("Field không hợp lệ.")

        if field in ["maxCons", "time", "cooldown"]:
            value = int(value)
        elif field in ["vip", "admin"]:
            value = value.lower() in ["1", "true", "yes", "on"]

        keys[key][field] = value
        save_keys(keys)
        await update.message.reply_text(f"Đã cập nhật `{field}` của key `{key}` thành `{value}`.")
    except:
        await update.message.reply_text("Sai cú pháp.\n/editkey <key> <field> <value>")

async def info_key(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        key = context.args[0]
        keys = load_keys()
        if key not in keys:
            return await update.message.reply_text("Key không tồn tại.")
        info = keys[key]
        message = "\n".join([f"{k}: {v}" for k, v in info.items()])
        await update.message.reply_text(f"Thông tin key `{key}`:\n{message}")
    except:
        await update.message.reply_text("Sai cú pháp.\n/infokey <key>")

async def list_keys(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keys = load_keys()
    if not keys:
        return await update.message.reply_text("Không có key nào.")
    reply = "\n".join(keys.keys())
    await update.message.reply_text(f"Danh sách key:\n{reply}")

async def ban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        key = context.args[0]
        keys = load_keys()
        if key in keys:
            keys[key]["banned"] = True
            save_keys(keys)
            await update.message.reply_text(f"Đã ban key `{key}`.")
        else:
            await update.message.reply_text("Key không tồn tại.")
    except:
        await update.message.reply_text("Sai cú pháp.\n/banuser <key>")

async def unban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        key = context.args[0]
        keys = load_keys()
        if key in keys:
            keys[key]["banned"] = False
            save_keys(keys)
            await update.message.reply_text(f"Đã unban key `{key}`.")
        else:
            await update.message.reply_text("Key không tồn tại.")
    except:
        await update.message.reply_text("Sai cú pháp.\n/unbanuser <key>")

def main():
    app = ApplicationBuilder().token("7864820460:AAFZlIsITpqSiOheeXH2qwWiIJBNAjkzRKU").build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("addkey", add_key))
    app.add_handler(CommandHandler("delkey", del_key))
    app.add_handler(CommandHandler("editkey", edit_key))
    app.add_handler(CommandHandler("infokey", info_key))
    app.add_handler(CommandHandler("listkey", list_keys))
    app.add_handler(CommandHandler("banuser", ban_user))
    app.add_handler(CommandHandler("unbanuser", unban_user))

    app.run_polling()

if __name__ == "__main__":
    main()