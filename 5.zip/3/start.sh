#!/bin/bash

echo "?? �ang c?p nh?t h? th?ng..."
sudo apt update -y

echo "?? C�i d?t Python v� pip..."
sudo apt install python3 python3-pip -y

echo "?? T?o thu m?c lucifer_api..."
mkdir -p lucifer_api && cd lucifer_api

echo "?? T?o file apis.json..."
cat <<EOF > apis.json
{
  "udp": {
    "api": [
      "http://example.com/api?host=<<\$host>>&port=<<\$port>>&time=<<\$time>>"
    ]
  }
}
EOF

echo "?? T?o file keys.json..."
cat <<EOF > keys.json
{
  "lucifer": {
    "user": "1337",
    "time": 2000,
    "expiry": "8/8/2030",
    "maxCons": "400",
    "banned": false,
    "admin": true,
    "vip": true,
    "whitelisted_ip": "none"
  }
}
EOF

echo "?? T?o file main.py..."
cat <<'EOF' > main.py
# (Paste to�n b? code Python ? tr�n v�o d�y ho?c m�nh s? g?i file ri�ng n?u b?n mu?n)
EOF

echo "?? C�i thu vi?n FastAPI v� Uvicorn..."
pip3 install fastapi uvicorn requests

echo "?? Kh?i ch?y server..."
uvicorn main:app --host 103.142.27.15 --port 80 --reload